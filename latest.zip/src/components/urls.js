var requestUrl="https://screeningtest.vdocipher.com/api/image/";
var imageUrl="https://screeningtest.vdocipher.com/api/image/";
var token ="fc1be0ce7f79cfe74502163bbc76613e";
export {requestUrl,imageUrl,token};