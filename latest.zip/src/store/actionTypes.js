const REQUESTCOMPLETE="requestComplete";
 const IMAGESLOADED="imagesLoaded";

export default {
    REQUESTCOMPLETE,
    IMAGESLOADED
}